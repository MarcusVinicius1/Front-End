import { FiltrarPorCpf, CarregarPessoasInJson, ToggleMessagebox } from './API.js'

const InputCpf = document.getElementById('InputSearch')
const BtnListaUser = document.getElementById('BtnListaUser')
const ImgPerfil = document.getElementById('ImgPerfil')
const SpanHora = document.getElementById('SpanHora')
const SpanData = document.getElementById('SpanData')
const SpanNome = document.getElementById('SpanNome')
const SpanSobrenome = document.getElementById('SpanSobrenome')
const SpanCpf = document.getElementById('SpanCpf')
const SpanEmail = document.getElementById('SpanEmail')
const SpanIdade = document.getElementById('SpanIdade')
const ListaDeUsuario = document.getElementById('ListaDeUsuario')
const PrintUsersInList = document.getElementById('PrintUsersInList')
const BtnBackListPerson = document.getElementById('BtnBackListPerson')
const Messagebox = document.getElementById('Messagebox')

let PersonList = []
CarregarPessoasInJson(PersonList, GerarListaDeUsuarios)

BtnListaUser.onclick = () => {
    ListaDeUsuario.style.height = '90vh'
    BtnBackListPerson.onclick = () => ListaDeUsuario.style.height = '0'
}

function ExibirInformacao() {
    const Resultado = FiltrarPorCpf(PersonList, InputCpf.value)
    
    if (typeof Resultado === 'string') {
        ToggleMessagebox(Messagebox, Resultado)
        return
    }

    if (InputCpf.value.length == 14) Messagebox.style.top = '-100px'

    const { NovaEntrada, Pessoa } = Resultado
    const UltimaEntrada = NovaEntrada[NovaEntrada.length - 1]

    SpanHora.textContent = UltimaEntrada.Hora || '...'
    SpanData.textContent = UltimaEntrada.Data || '...'
    ImgPerfil.src = Pessoa.Perfil || ''
    SpanNome.textContent = Pessoa.Nome || '...'
    SpanSobrenome.textContent = Pessoa.Sobrenome || '...'
    SpanCpf.textContent = Pessoa.Cpf || '...'
    SpanEmail.textContent = Pessoa.Email || '...'
    SpanIdade.textContent = Pessoa.Idade || '...'
}

function GerarListaDeUsuarios() {
    PrintUsersInList.innerHTML = ''

    PersonList.forEach(person => {
        const CardListUsers = document.createElement('div')
        CardListUsers.classList = 'CardListUsers'

        const ImgPerfilInList = document.createElement('img')
        ImgPerfilInList.src = person.Perfil

        const InfoPersonInList = document.createElement('div')
        InfoPersonInList.classList = 'InfoPersonInList'

        const H4Nome = document.createElement('h4')
        H4Nome.innerHTML = `Nome: <span>${person.Nome}</span>`

        const H4Sobrenome = document.createElement('h4')
        H4Sobrenome.innerHTML = `Sobrenome: <span>${person.Sobrenome}</span>`

        const H4Cpf = document.createElement('h4')
        H4Cpf.innerHTML = `Cpf: <span>${person.Cpf}</span>`

        const H4Email = document.createElement('h4')
        H4Email.innerHTML = `Email: <span>${person.Email}</span>`

        const H4Idade = document.createElement('h4')
        H4Idade.innerHTML = `Idade: <span>${person.Idade}</span>`

        PrintUsersInList.appendChild(CardListUsers)
        CardListUsers.appendChild(ImgPerfilInList)
        CardListUsers.appendChild(InfoPersonInList)
        InfoPersonInList.append(H4Nome, H4Sobrenome, H4Cpf, H4Email, H4Idade)
    })
}

function ResetarCampos() {
    SpanHora.textContent = '...'
    SpanData.textContent = '...'
    ImgPerfil.src = ''
    SpanNome.textContent = '...'
    SpanSobrenome.textContent = '...'
    SpanCpf.textContent = '...'
    SpanEmail.textContent = '...'
    SpanIdade.textContent = '...'
}

ResetarCampos()

InputCpf.oninput = () => ExibirInformacao()
ImgPerfil.onclick = () => ImgPerfil.classList.toggle('ToggleImg')