const TextareaDescricao = document.getElementById('TextareaDescricao')
const InputSetor = document.getElementById('InputSetor')

