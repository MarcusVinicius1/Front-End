const express = require('express')
const fs = require('fs').promises
const path = require('path')
const cors = require('cors')

const app = express()
const PORT = 3000
const DATA_FILE = path.join(__dirname, 'data.json')

app.use(cors())
app.use(express.json())

// Rota para salvar usuário
app.post('/api/usuarios', async (req, res) => {
    try {
        let usuarios = []
        
        // Tenta ler o arquivo existente
        try {
            const data = await fs.readFile(DATA_FILE, 'utf8')
            usuarios = JSON.parse(data)
        } catch (err) {
            if (err.code !== 'ENOENT') throw err
        }

        // Adiciona o novo usuário
        usuarios.push(req.body)

        // Salva no arquivo
        await fs.writeFile(DATA_FILE, JSON.stringify(usuarios, null, 2))
        
        res.status(201).json(req.body)
    } catch (err) {
        console.error(err)
        res.status(500).json({ error: 'Erro ao salvar usuário' })
    }
})

// Inicia o servidor
app.listen(PORT, () => {
    console.log(`Servidor rodando em http://localhost:${PORT}`)
})