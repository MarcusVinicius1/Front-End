import { SalvarRelatorio } from './API.js'

const BtnSalvarRelatorio = document.getElementById("BtnSalvarRelatorio")
const BtnVerRelatorio = document.getElementById("BtnVerRelatorio")
const InputFicha = document.getElementById("InputFicha")
const InputDesempenho = document.getElementById("InputDesempenho")
const BtnBackHome = document.getElementById('BtnBackHome')
const ContainerVerRelatorio = document.getElementById("ContainerVerRelatorio")
const PrintRelatorio = document.getElementById("PrintRelatorio")
const InputFiltroRelatorio = document.getElementById("InputFiltroRelatorio")

const Info = JSON.parse(localStorage.getItem('Relatorio')) || []

BtnSalvarRelatorio.onclick = () => {
    if (!InputFicha.value) {
        alert("Preencher o canpo de ficha!")
    }

    if (!InputDesempenho.value) {
        alert("Preencher o canpo de desempenho!")
        return
    }

    SalvarRelatorio(InputFicha.value, InputDesempenho.value, Info)
    InputFicha.value = '' 
    InputDesempenho.value = ''
}

BtnVerRelatorio.onclick = () => {
    ContainerVerRelatorio.style.height = 'auto'

    PrintRelatorio.innerHTML = ''
    const relatorioData = JSON.parse(localStorage.getItem('Relatorio'))

    if (relatorioData && Array.isArray(relatorioData)) {
        relatorioData.forEach(report => {
            const CardRelatorio = document.createElement("div")
            CardRelatorio.classList = 'CardRelatorio'

            const H4TipoFicha = document.createElement("h4")
            H4TipoFicha.textContent = `Ficha: ${report.Ficha}`

            const SpanDesempenho = document.createElement('span')
            SpanDesempenho.textContent = `Desempenho: ${report.Desempenho}`

            const SpanDataRelatorio = document.createElement('span')
            SpanDataRelatorio.textContent = `${report.Hora} | ${report.Data} | ${report.Semana}`

            CardRelatorio.appendChild(H4TipoFicha)
            CardRelatorio.appendChild(SpanDesempenho)
            CardRelatorio.appendChild(SpanDataRelatorio)
            PrintRelatorio.appendChild(CardRelatorio)
        })
    } else {
        console.error('No valid Relatorio data found in localStorage')
    }

    BtnBackHome.onclick = () => ContainerVerRelatorio.style.height = '0'
}

InputFiltroRelatorio.oninput = () => {
    const Relatorio = JSON.parse(localStorage.getItem('Relatorio'))

    if (Relatorio && Array.isArray(Relatorio)) {
        const filtroTexto = InputFiltroRelatorio.value.toLowerCase()
        
        const RelatorioFiltrados = Relatorio.filter(report => {
            return report.Ficha.toLowerCase().includes(filtroTexto)
        })

        PrintRelatorio.innerHTML = ''

        if (RelatorioFiltrados.length > 0) {
            RelatorioFiltrados.forEach(report => {
                const CardRelatorio = document.createElement("div")
                CardRelatorio.classList = 'CardRelatorio'

                const H4TipoFicha = document.createElement("h4")
                H4TipoFicha.textContent = `Ficha: ${report.Ficha}`

                const SpanDesempenho = document.createElement('span')
                SpanDesempenho.textContent = `Desempenho: ${report.Desempenho}`

                const SpanDataRelatorio = document.createElement('span')
                SpanDataRelatorio.textContent = `${report.Hora} | ${report.Data} | ${report.Semana}`

                CardRelatorio.appendChild(H4TipoFicha)
                CardRelatorio.appendChild(SpanDesempenho)
                CardRelatorio.appendChild(SpanDataRelatorio)
                PrintRelatorio.appendChild(CardRelatorio)
            })
        } else {
            PrintRelatorio.innerHTML = 'Nenhum relatório encontrado!'
        }
    } else {
        console.error('No valid Relatorio data found in localStorage')
    }
}
