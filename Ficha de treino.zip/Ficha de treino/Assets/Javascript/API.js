const FormatTime = n => n < 10 ? n = `0${n}` : n

function CreateListaTreino(ChaveTreino) {
    PrintTreinoDeHoje.innerHTML = ''
    
    for (let i = 0; i < ChaveTreino.length; i++) {
        const UlTag = document.createElement('ul')
    
        const LiTag = document.createElement('li')
        LiTag.textContent = `${FormatTime(i+1)}° ${ChaveTreino[i]}`
    
        PrintTreinoDeHoje.appendChild(UlTag)
        UlTag.appendChild(LiTag)
    }
}

function DateSemana() {
    const DiaDaSemana = ['Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado', 'Domingo']
    let DiaDaSemanaHoje = ''
    let FichaPraHoje = ''
    const NewSemana = new Date().getDay()
    DiaDaSemanaHoje = DiaDaSemana[NewSemana - 1]
    
    switch (DiaDaSemanaHoje) {
        case 'Segunda':
            FichaPraHoje = 'A'
        break
        case 'Terça':
            FichaPraHoje = 'B'
        break
        case 'Quarta':
            FichaPraHoje = 'C'
        break
        case 'Quinta':
            FichaPraHoje = 'D'
        break
        case 'Sexta':
            FichaPraHoje = 'E'
        break
        case 'Sábado':
        case 'Domingo':
            console.log('Hoje é dia de descanso!')
        break
    }
    
    return FichaPraHoje
}

function CalcularImc(Altura, Peso, Saida) {
    if (!Altura) {
        alert('Preencha o dado da altura')
    }
    
    if (!Peso) {
        alert('Peecha o dado do peso')
        return
    }
    
    let Imc = Peso / (Altura * Altura)
    Saida.textContent = Imc.toFixed(2)
    
    return Saida
}

function SalvarRelatorio(ficha, desempenho, Info) {
    const DiaDaSemana = ['Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado', 'Domingo']
    const NewDate = new Date()

    let hh = FormatTime(NewDate.getHours())
    let mm = FormatTime(NewDate.getMinutes())
    let Dia = FormatTime(NewDate.getDate())
    let Mes = FormatTime(NewDate.getMonth()+1)
    let Ano = NewDate.getFullYear()
    let DiaSemana = NewDate.getDay()

    const HoraRelatorio = `${hh}:${mm}`
    const DataRelatorio = `${Dia}/${Mes}/${Ano}`
    const SemanaRelatorio = DiaDaSemana[DiaSemana - 1]

    Info.push({ Ficha: ficha, Desempenho: desempenho, Hora: HoraRelatorio, Data: DataRelatorio, Semana: SemanaRelatorio})

    localStorage.setItem('Relatorio', JSON.stringify(Info))
}

export { CreateListaTreino, DateSemana, CalcularImc, SalvarRelatorio }