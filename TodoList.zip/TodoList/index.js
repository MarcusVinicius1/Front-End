const InputTasks = document.getElementById("InputTasks")
const InputCategoria = document.getElementById("InputCategoria")
const InputImportancia = document.getElementById("InputImportancia")
const BtnAdd = document.getElementById("BtnAdd")
const TasksInAdd = document.getElementById("TasksInAdd")
const SpanTasksConcluidas = document.getElementById("SpanTasksConcluidas")
const SpanTotalTasks = document.getElementById('SpanTotalTasks')
const SpanTasksPendentes = document.getElementById("SpanTasksPendentes")
const PrintTasksConcluidas = document.getElementById("PrintTasksConcluidas")
const OpenTarefasConcluidas = document.getElementById("OpenTarefasConcluidas")
const CloseTarefasConcluidas = document.getElementById('CloseTarefasConcluidas')
const TasksConcluidas = document.getElementById('TasksConcluidas')

let ListTasks = JSON.parse(localStorage.getItem('Task')) || []
let CountTasks = 0
let CountTasksConcluidas = 0

// Função para criar HTML das tarefas pendentes
function createTaskHtml(task, index) {
    return `
        <div class="Card">
            <h2>${task.Task}</h2>
            <div class="Info">
                <span>${task.Task} - ${task.Categoria} - Prioridade: ${task.Prioridade}</span>
                <div class="Controls">
                    <button class="complete" data-index="${index}">Completar</button>
                    <button class="remove" data-index="${index}">Remover</button>
                </div>
            </div>
        </div>
    `
}

// Função para criar HTML das tarefas concluídas
function createTaskConcluidas(task, index) {
    return `
        <div class="Card">
            <span>${task.Task} - Prioridade: ${task.Prioridade}</span>
            <button class="restore" data-index="${index}">Restaurar</button>
        </div>
    `
}

// Função para carregar e exibir as tarefas
function loadTasks() {
    TasksInAdd.innerHTML = ''
    PrintTasksConcluidas.innerHTML = '' // Limpa as tarefas concluídas
    CountTasks = 0
    CountTasksConcluidas = 0

    if (ListTasks.length === 0) {
        TasksInAdd.innerHTML = '<p>Sem tarefas!</p>'
    }

    // Percorre a lista 'Task' no localStorage
    ListTasks.forEach((task, index) => {
        if (task.Status === 'Completo') {
            CountTasksConcluidas++
            PrintTasksConcluidas.innerHTML += createTaskConcluidas(task, index)

        } else {
            CountTasks++
            TasksInAdd.innerHTML += createTaskHtml(task, index)
        }
    })

    if (PrintTasksConcluidas.innerHTML === '') {
        PrintTasksConcluidas.innerHTML = '<p>Sem tarefas concluídas!</p>'
    }

    SpanTotalTasks.textContent = CountTasks + CountTasksConcluidas
    SpanTasksPendentes.textContent = CountTasks
    SpanTasksConcluidas.textContent = CountTasksConcluidas

    // Re-adiciona os event listeners após a atualização do HTML
    addEventListeners()
}

// Função para adicionar os event listeners nos botões
function addEventListeners() {
    // Adiciona os listeners para os botões de "Completar", "Remover" e "Restaurar"
    const completeButtons = document.querySelectorAll('.complete')
    const removeButtons = document.querySelectorAll('.remove')
    const restoreButtons = document.querySelectorAll('.restore')

    completeButtons.forEach(button => {
        button.addEventListener('click', handleComplete)
    })

    removeButtons.forEach(button => {
        button.addEventListener('click', handleRemove)
    })

    restoreButtons.forEach(button => {
        button.addEventListener('click', handleRestore)
    })
}

// Função para completar uma tarefa
function handleComplete(event) {
    const index = event.target.getAttribute('data-index')
    ListTasks[index].Status = 'Completo' // Altera o status da tarefa para 'Completo'
    updateLocalStorage()
    loadTasks() // Recarrega as tarefas
}

// Função para remover uma tarefa
function handleRemove(event) {
    const index = event.target.getAttribute('data-index')
    ListTasks.splice(index, 1) // Remove a tarefa da lista
    updateLocalStorage()
    loadTasks() // Recarrega as tarefas
}

// Função para restaurar uma tarefa
function handleRestore(event) {
    const index = event.target.getAttribute('data-index')
    ListTasks[index].Status = 'Pendente'; // Muda o status da tarefa para 'Pendente'
    updateLocalStorage()
    loadTasks() // Recarrega as tarefas
}

// Função para atualizar o localStorage
function updateLocalStorage() {
    localStorage.setItem('Task', JSON.stringify(ListTasks))
}

// Função que adiciona uma nova tarefa
BtnAdd.onclick = () => {
    if (InputTasks.value.trim() === '' || InputCategoria.value.trim() === '' || InputImportancia.value.trim() === '') {
        alert('Por favor, preencha todos os campos.')
        return
    }

    const newTask = {
        Task: InputTasks.value,
        Categoria: InputCategoria.value,
        Prioridade: InputImportancia.value,
        Status: 'Pendente',
    }

    ListTasks.push(newTask)
    updateLocalStorage()
    loadTasks() // Recarrega as tarefas

    // Limpa os campos de entrada
    InputTasks.value = ''
    InputCategoria.value = ''
    InputImportancia.value = ''
}

// Função paa abrir a lista de tarefas concluidas
OpenTarefasConcluidas.onclick = () => {
    TasksConcluidas.style.display = 'block'

    CloseTarefasConcluidas.onclick = () => TasksConcluidas.style.display = 'none'
}

// Carrega as tarefas quando a página é carregada
window.onload = loadTasks
