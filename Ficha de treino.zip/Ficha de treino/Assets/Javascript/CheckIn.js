const ContainerCheckIn = document.getElementById('ContainerCheckIn')

const DiasSemanaDate = ['Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb', 'Dom']
const ArrDiasSemana = ['Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado', 'Domingo']

function CreateCardCheckIn() {
    ContainerCheckIn.innerHTML = ''

    const currentDate = new Date()
    const currentDay = currentDate.getDay()
    
    for (let i = 0; i < 5; i++) {
        const CardCheckIn = document.createElement('div')
        CardCheckIn.className = 'CardCheckIn'
        
        const SpanDiaCheckIn = document.createElement('span')
        SpanDiaCheckIn.textContent = DiasSemanaDate[i]
        
        const SpanDataCheckIn = document.createElement('span')
        const dateForCard = new Date(currentDate)

        dateForCard.setDate(currentDate.getDate() + (i - currentDay))
        SpanDataCheckIn.textContent = dateForCard.getDate() + 1
        
        CardCheckIn.addEventListener('click', () => {
            if (SpanDiaCheckIn.textContent != ArrDiasSemana[i]) {
                CardCheckIn.style.background = 'black'
                CardCheckIn.style.color = 'white'

            }else {
                CardCheckIn.style.background = 'white'
                CardCheckIn.style.color = 'black'
            }
        })

        ContainerCheckIn.appendChild(CardCheckIn)
        CardCheckIn.appendChild(SpanDiaCheckIn)
        CardCheckIn.appendChild(SpanDataCheckIn)
    }
}

setInterval(() => {
    CreateCardCheckIn()
}, 60000)

CreateCardCheckIn()
