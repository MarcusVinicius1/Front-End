async function SalvarUsuario(usuario) {
    try {
        const response = await fetch('http://localhost:3000/api/usuarios', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(usuario)
        })

        if (!response.ok) {
            throw new Error('Erro ao salvar usuário');
        }

        const data = await response.json()
        console.log("Usuário salvo com sucesso!", data)
        return data
    }catch (e) {
        console.error('Erro ao salvar o usuário', e)
        throw e
    }
}

export { SalvarUsuario }