import { CreateListaTreino, DateSemana, CalcularImc } from './API.js'

const PrintTreinoDeHoje = document.getElementById('PrintTreinoDeHoje')
const BtnDiaTreino = document.querySelectorAll('.BtnDiaTreino')
const BtnCalcularImc = document.getElementById('BtnCalcularImc')
const BtnTabelaImc = document.getElementById('BtnTabelaImc')
const InputAlturaImc = document.getElementById('InputAlturaImc')
const InputPesoImc = document.getElementById('InputPesoImc')
const SpanResultImc = document.getElementById('SpanResultImc')
const ToggleImc = document.getElementById('ToggleImc')
const ImcCalculadora = document.getElementById('ImcCalculadora')
const CronometroTime = document.getElementById('CronometroTime')
const TabelaImc = document.getElementById('TabelaImc')
const ResultImc = document.getElementById('ResultImc')
const ToggleRelatorio = document.getElementById("ToggleRelatorio")
const ContaineRelatorio = document.getElementById('ContaineRelatorio')

const Fichas = {
    A: [
        'Peitoral inclinado', 'Peitoral frontal', 'Peitoral cross alto', 
        'Crusifixo', 'Crusifixo cross baixo', 'Elevação unilateral cross', 
        'Remada alta cross', 'Triceps corda com triceps testa', 
        'Triceps frances', 'Triceps unilateral'
    ],
    B: [
        'Flexão de joelho', 'Leg 45°', 'Hack', 'Leg 45° unilateral', 
        'Cadeira extensora', 'Panturrilha leg', 'Panturrilha sentado'
    ],
    C: [
        'Puxada frente neutro', 'Puxada frente triangulo', 
        'Remada alta maquina', 'Remada unilateral articulado', 
        'Remada serrote', 'Pulldown', 'Rosca direta cross', 
        'Rosca scott', 'Rosca concentrada', 'Rosca inversa', 'Antibraço'
    ],
    D: [
        'Stiff','Flexão de joelho','Mesa flexora','Cadeira flexora',
        'Elevação pelvica','Cadeira abdutora','Panturrilha leg', 'Panturrilha sentado'
    ],
    E: [
        'Elevação fronta com anilha com elevação unilateral com halter',
        'Elevação lateral rest-pause','Desenvolvimento maquina','Crusifixo inclinado articulado',
        'Remada alta cross','Elevação lateral'
    ]
}

const QualTreinoHoje = DateSemana()

BtnDiaTreino.forEach(btn => {
    if (QualTreinoHoje == btn.textContent) btn.classList.add('ActiveDiaFicha')
    else btn.classList.remove('ActiveDiaFicha')
    
    btn.onclick = () => {
        CreateListaTreino(Fichas[btn.textContent])
        LiHome.click()
        CronometroTime.style.display = 'none'
        PrintTreinoDeHoje.style.display = 'block'
    }
})

BtnCalcularImc.onclick = () => {
    ResultImc.style.display = 'grid'
    CalcularImc(InputAlturaImc.value, InputPesoImc.value, SpanResultImc)
    
    InputAlturaImc.value = ''
    InputPesoImc.value = ''
}

ToggleImc.onclick = () => {
    
    if (PrintTreinoDeHoje.style.display != 'none') {
        ContaineRelatorio.style.display = 'none'
        PrintTreinoDeHoje.style.display = 'none'
        ImcCalculadora.style.display = 'block'
        
    }else {
        PrintTreinoDeHoje.style.display = 'block'
        ImcCalculadora.style.display = 'none'
    }
}

BtnTabelaImc.onclick = () => {
    ResultImc.style.display = 'none'
    TabelaImc.style.display = 'block'
}

ToggleRelatorio.onclick = () => {
    
    if (ContaineRelatorio.style.display != 'flex') {
        ImcCalculadora.style.display = 'none'
        PrintTreinoDeHoje.style.display = 'none'
        ContaineRelatorio.style.display = 'flex'
        
    }else {
        ContaineRelatorio.style.display = 'none'
    }
}