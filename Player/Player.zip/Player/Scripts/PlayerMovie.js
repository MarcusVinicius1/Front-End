"use strict"

const BtnPlayMovie = document.getElementById('BtnPlayMovie')
const BtnPauseMovie = document.getElementById('BtnPauseMovie')
const BtnNextMovie = document.getElementById('BtnNextMovie')
const BtnBackMovie = document.getElementById('BtnBackMovie')
const BtnFullscreenMovie = document.getElementById('BtnFullscreenMovie')
const InsertVideo = document.getElementById('InsertVideo')
const InsertVideoBlur = document.getElementById("InsertVideoBlur")
const SpanTimeMovie = document.getElementById('SpanTimeMovie')
const SpanDurationMovie = document.getElementById('SpanDurationMovie')
const ProgressBarraMovie = document.getElementById('ProgressBarraMovie')
const PrintVideoArchive = document.getElementById("PrintVideoArchive")
const ContainerProgressMovie = document.getElementById("ContainerProgressMovie")
const Controls = document.getElementById("Controls")

const VideosLista = [
    {
        Titulo: 'Conheça os segredos para usar o display de LCD no Arduino via I2C',
        src: 'Videos/Conheça os segredos para usar o display de LCD no Arduino via I2C.mp4',
        Capa: '../Capa/Videos/Um.jpg'
    },
    {
        Titulo: 'ASMR Programming - Spinning Cube - No Talking',
        src: 'Videos/ASMR Programming - Spinning Cube - No Talking.mp4',
        Capa: '../Capa/Videos/Dois.jpg'
    }
]

let IndexVideo = 0

function CreateCardMovieArchive() {
    PrintVideoArchive.innerHTML = ''

    for (let i = 0; i < VideosLista.length; i++) {
        const CardVideo = document.createElement('div')
        CardVideo.classList = 'CardVideo'

        const Img = document.createElement('img')
        Img.src = VideosLista[i].Capa

        const H4Title = document.createElement("h4")
        H4Title.textContent = VideosLista[i].Titulo

        CardVideo.onclick = () => {
            ListPlayer.style.display = 'none'

            PlayerMusic.style.display = 'none'
            PlayerVideo.style.display = 'flex'

            SpanTrocaMusicOrMovie.classList = 'fa-solid fa-music'
            MovieOrSong.textContent = 'Video'

            document.title = 'Player - Video'

            InsertVideo.src = VideosLista[i].src
            // Atualiza a duração do vídeo após o carregamento completo
            InsertVideo.onloadedmetadata = () => {
                SpanDurationMovie.textContent = `${FormatTime(Math.floor(InsertVideo.duration / 60))}:${FormatTime(Math.floor(InsertVideo.duration % 60))}`
            }

            IndexVideo = i
            BtnPlayMovie.click()
        }

        PrintVideoArchive.appendChild(CardVideo)
        CardVideo.appendChild(Img)
        CardVideo.appendChild(H4Title)
    }
}

const changeMovie = () => {
    const movie = VideosLista[IndexVideo]
    InsertVideo.src = movie.src
    InsertVideoBlur.src = movie.src

    InsertVideo.onloadedmetadata = () => {
        SpanDurationMovie.textContent = `${FormatTime(Math.floor(InsertVideo.duration / 60))}:${FormatTime(Math.floor(InsertVideo.duration % 60))}`
    }

    InsertVideo.play().catch(error => {
        console.error("Erro ao tentar reproduzir o vídeo:", error)
        alert("Ocorreu um erro ao tentar carregar o vídeo. Tente novamente.")
    })

    BtnPlayMovie.style.display = 'none'
    BtnPauseMovie.style.display = 'grid'
}

BtnPlayMovie.onclick = () => {
    changeMovie()
    BtnPlayMovie.style.display = 'none'
    BtnPauseMovie.style.display = 'grid'

    Controls.style.marginBottom = '80px'
    ContainerProgressMovie.style.marginBottom = '60px'
}

BtnPauseMovie.onclick = () => {
    InsertVideo.pause()
    InsertVideoBlur.pause()
    BtnPlayMovie.style.display = 'grid'
    BtnPauseMovie.style.display = 'none'

    Controls.style.marginBottom = '20px'
    ContainerProgressMovie.style.marginBottom = '-50px'
}

BtnNextMovie.onclick = () => {
    IndexVideo = (IndexVideo + 1) % VideosLista.length
    changeMovie()
    Controls.style.marginBottom = '80px'
    ContainerProgressMovie.style.marginBottom = '60px'
}

BtnBackMovie.onclick = () => {
    IndexVideo = (IndexVideo - 1 + VideosLista.length) % VideosLista.length
    changeMovie()
    Controls.style.marginBottom = '80px'
    ContainerProgressMovie.style.marginBottom = '60px'
}

BtnFullscreenMovie.onclick = () => {
    if (InsertVideo.requestFullscreen) {
        InsertVideo.requestFullscreen()
    } else if (InsertVideo.mozRequestFullScreen) { // Firefox
        InsertVideo.mozRequestFullScreen()
    } else if (InsertVideo.webkitRequestFullscreen) { // Chrome and Safari
        InsertVideo.webkitRequestFullscreen()
    } else if (InsertVideo.msRequestFullscreen) { // IE/Edge
        InsertVideo.msRequestFullscreen()
    }
}

InsertVideo.ontimeupdate = () => {
    const currentTime = InsertVideo.currentTime
    const duration = InsertVideo.duration
    SpanTimeMovie.textContent = `${FormatTime(Math.floor(currentTime / 60))}:${FormatTime(Math.floor(currentTime % 60))}`
    ProgressBarraMovie.style.width = `${(currentTime / duration) * 100}%`
}

InsertVideo.onended = () => {
    IndexVideo = (IndexVideo + 1) % VideosLista.length
    changeMovie()
}

window.addEventListener('resize', () => {
    if (window.innerWidth < 768) {
        Controls.style.flexDirection = 'column'
        ContainerProgressMovie.style.flexDirection = 'column'
    } else {
        Controls.style.flexDirection = 'row'
        ContainerProgressMovie.style.flexDirection = 'row'
    }
})
