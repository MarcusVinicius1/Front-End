const IToggleVerPass = document.getElementById('IToggleVerPass')    
const InputPasswordLogin = document.getElementById('InputPasswordLogin')

IToggleVerPass.onclick = () => {
    if (IToggleVerPass.classList.contains("fa-eye")) {
        InputPasswordLogin.type = "text"
        IToggleVerPass.classList.remove("fa-eye")
        IToggleVerPass.classList.add("fa-eye-slash")
        
    }else {
        InputPasswordLogin.type = "password"
        IToggleVerPass.classList.remove("fa-eye-slash")
        IToggleVerPass.classList.add("fa-eye")
    }
}
