import { SalvarUsuario } from '../Assets/Javascript/SaveUser.js'

const BtnCadastrarUser = document.getElementById('BtnCadastrarUser')
const InputNomeUser = document.getElementById('InputNomeUser')
const InputEmailUser = document.getElementById('InputEmailUser')

const Regex_Email = /^[^\s@]+@[^\s@]+\.[^\s@]+$/

const Verificar_Canpo_Text = (Valor) => {
    return Valor.trim() !== ''
}

BtnCadastrarUser.addEventListener('click', async (e) => {
    e.preventDefault()

    if (!Verificar_Canpo_Text(InputNomeUser.value)) {
        InputNomeUser.style.background = 'tomato'
        InputNomeUser.onclick = () => InputNomeUser.style.background = 'none'
        return
    }

    if (!Verificar_Canpo_Text(InputEmailUser.value)) {
        InputEmailUser.style.background = 'tomato'
        InputEmailUser.onclick = () => InputEmailUser.style.background = 'none'
        return
    }

    if (!Regex_Email.test(InputEmailUser.value)) {
        alert("Email inválido!")
        InputEmailUser.style.background = 'red'
        InputEmailUser.onclick = () => InputEmailUser.style.background = 'none'
        return
    }

    try {
        const NovoUsuario = {
            Nome: InputNomeUser.value,
            Email: InputEmailUser.value
        }
        
        await SalvarUsuario(NovoUsuario) // Envia apenas o novo usuário

        alert(`${InputNomeUser.value}, foi cadastrado(a)!`)
        InputNomeUser.value = ''
        InputEmailUser.value = ''
    } catch (e) {
        alert('Não foi possível cadastrar esse usuário!')
        console.error(e)
    }
})