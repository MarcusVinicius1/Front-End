const BtnCadastrarUserActive = document.getElementById('BtnCadastrarUserActive')
const BtnCadastroDeTarefas = document.getElementById('BtnCadastroDeTarefas')
const BtnGereciarTarefas = document.getElementById('BtnGereciarTarefas')

const CadastroDeUsuario = document.getElementById('CadastroDeUsuario')
const CadastroTarefa = document.getElementById('CadastroTarefa')
const PrintTasks = document.getElementById('PrintTasks')

const buttonSessionMap = [
    { button: BtnCadastrarUserActive, session: CadastroDeUsuario },
    { button: BtnCadastroDeTarefas, session: CadastroTarefa },
    { button: BtnGereciarTarefas, session: PrintTasks }
]

const BackgroundBtn = (map) => {
    map.forEach(({ button, session }) => {
        button.onclick = () => {
            map.forEach(({ button: btn, session: sess }) => {
                btn.style.background = 'none'
                btn.style.boxShadow = 'none'
                sess.style.display = 'none'
            })

            button.style.background = 'black'
            button.style.boxShadow = '0 0 10px black'
            session.style.display = 'block'
        }
    })
}

BackgroundBtn(buttonSessionMap)