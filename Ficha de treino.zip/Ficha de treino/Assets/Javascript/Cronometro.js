const SpanCrono = document.getElementById('SpanCrono')
const SpanTemp = document.getElementById('SpanTemp')
const BtnPlayTime = document.getElementById('BtnPlayTime')
const BtnPauseTime = document.getElementById('BtnPauseTime')
const BtnZerarTime = document.getElementById('BtnZerarTime')

let HoraCrono = 0
let MinutoCrono = 0
let SegundoCrono = 0
let HoraTemp = 0
let MinutoTemp = 30
let SegundoTemp = 0
const FormatTime = n => n < 10 ? n = `0${n}` : n
let IntervalTime

BtnPlayTime.onclick = () => {
    BtnPlayTime.style.display = 'none'
    BtnPauseTime.style.display = 'block'
    BtnZerarTime.style.display = 'block'
    
    IntervalTime = setInterval(() => {
        SegundoCrono++
        SegundoTemp--
        
        if (SegundoCrono >= 60) {
            SegundoCrono = 0
            MinutoCrono++
        }
        
        if (MinutoCrono >= 60) {
            MinutoCrono = 0
            HoraCrono++
        }
        
        if (SegundoTemp <= 0) {
            SegundoTemp = 59
            MinutoTemp--
        }
        
        if (MinutoTemp <= 0) {
            MinutoTemp = 59
            HoraTemp--
        }
        
        if (HoraTemp <= 0) {
            HoraTemp = 0
        }
        
        SpanCrono.textContent = `${FormatTime(HoraCrono)}:${FormatTime(MinutoCrono)}:${FormatTime(SegundoCrono)}`
        SpanTemp.textContent = `${FormatTime(HoraTemp)}:${FormatTime(MinutoTemp)}:${FormatTime(SegundoTemp)}`
    }, 1000)
}

BtnPauseTime.onclick = () => {
    clearInterval(IntervalTime)
    BtnPlayTime.style.display = 'block'
    BtnPauseTime.style.display = 'none'
}

BtnZerarTime.onclick = () => {
    clearInterval(IntervalTime)
    
    HoraCrono = 0
    MinutoCrono = 0
    SegundoCrono = 0
    HoraTemp = 0
    MinutoTemp = 30
    SegundoTemp = 0
    
    SpanCrono.textContent = `${FormatTime(HoraCrono)}:${FormatTime(MinutoCrono)}:${FormatTime(SegundoCrono)}`
    SpanTemp.textContent = `${FormatTime(HoraTemp)}:${FormatTime(MinutoTemp)}:${FormatTime(SegundoTemp)}`
    
    BtnPlayTime.style.display = 'block'
    BtnPauseTime.style.display = 'none'
    BtnZerarTime.style.display = 'none'
}