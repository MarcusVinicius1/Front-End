const ImagesVetor = [
    'Images/Um.jpg',
    'Images/Dois.jpg',
    'Images/Trez.jpg'
]
const body = document.body

function BackgroundImage(Vetor, Delay, Obj) {
    setInterval(() => {
        const RandomBg = Vetor[Math.floor(Math.random() * Vetor.length)]

        Obj.style.background = `url('${RandomBg}')`
        Obj.style.backgroundPosition = 'center'
        Obj.style.backgroundSize = 'cover'
    }, Delay)
}

BackgroundImage(ImagesVetor, 2000, body)