const FormatTime = n => String(n).padStart(2, '0')

function DateAtual() {
    try {
        const NewDate = new Date()
        const Hora = FormatTime(NewDate.getHours())
        const Minuto = FormatTime(NewDate.getMinutes())
        const Segundo = FormatTime(NewDate.getSeconds())
        const Dia = FormatTime(NewDate.getDate())
        const Mes = FormatTime(NewDate.getMonth() + 1)
        const Ano = NewDate.getFullYear()

        return {
            FormatHora: `${Hora}:${Minuto}:${Segundo}`,
            FormatData: `${Dia}/${Mes}/${Ano}`
        }

    } catch (e) {
        console.error('Erro ao obter a data atual: ', e.message)
        throw new Error(e)
    }
}

function EnviarInformacao(Vetor, Pessoa) {
    try {
        const { FormatHora, FormatData } = DateAtual()
        const NovaEntrada = [...Vetor, { Hora: FormatHora, Data: FormatData }]

        return { NovaEntrada, Pessoa }

    } catch (e) {
        console.error('Erro ao enviar a informação: ', e.message)
        throw new Error(e)
    }
}

function FiltrarPorCpf(Vetor, Cpf) {
    try {
        if (!Cpf) return 'CPF inválido!'
        if (!Array.isArray(Vetor) || Vetor.length === 0) return 'A lista está vazia!'

        const Pessoa = Vetor.find(pessoa => pessoa.Cpf === Cpf)

        return Pessoa ? EnviarInformacao(Vetor, Pessoa) : 'CPF não encontrado'

    } catch (e) {
        console.error('Erro ao filtrar pelo CPF: ', e.message)
        throw new Error(e)
    }
}

async function CarregarPessoasInJson(PersonList, GerarListaDeUsuarios) {
    try {
        const response = await fetch('./data.json')
        if (!response.ok) throw new Error('Erro ao buscar o JSON')
        
        const data = await response.json();
        PersonList.length = 0
        
        PersonList.push(...data)

        if (PersonList.length === 0) {
            console.log('A lista está vazia!')

        } else {
            GerarListaDeUsuarios()
        }
    } catch (error) {
        console.error('Erro ao carregar o arquivo JSON: ', error.message)
    }
}

function ToggleMessagebox(Menssager, MessagemInput) {
    if (MessagemInput.length === 14) {
        Menssager.style.top = '-100px'

    }else {
        Menssager.textContent = MessagemInput
        Menssager.style.top = '70px'

        setTimeout(() => {
            Menssager.style.top = '-100px'
        }, 3000)
    }
}

export { FiltrarPorCpf, CarregarPessoasInJson, ToggleMessagebox }