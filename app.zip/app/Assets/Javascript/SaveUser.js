async function SalvarUsuario(UsersList) {
    try {
        const response = await fetch('data.json')
        if (!response.ok) {
            console.log("Data não encontrado!")
            return
        }
        const data = await response.json()
        data.push(...UsersList)
        console.log("Usuários salvos com sucesso!", data)
    }catch (e) {
        console.log('Error ao salvar o usuario(a)', e)
    }
}

export { SalvarUsuario }