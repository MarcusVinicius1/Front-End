const BtnMusicOrVideo = document.getElementById('BtnMusicOrVideo')
const BtnOpenArchive = document.getElementById('BtnOpenArchive')
const SpanTrocaMusicOrMovie = document.getElementById('SpanTrocaMusicOrMovie')
const MovieOrSong = document.getElementById('MovieOrSong')
const PlayerMusic = document.getElementById('PlayerMusic')
const PlayerVideo = document.getElementById('PlayerVideo')
const FecharArchive = document.getElementById('FecharArchive')
const ListPlayer = document.getElementById('ListPlayer')
const BtnOpenVideosArchive = document.getElementById('BtnOpenVideosArchive')
const BtnOpenMusicasArchive = document.getElementById('BtnOpenMusicasArchive')
const BtnOpenIluminacao = document.getElementById('BtnOpenIluminacao')
const ContainerLuminacao = document.getElementById("ContainerLuminacao")
const InputIluminacao = document.getElementById("InputIluminacao")
const SpanLuminosidade = document.getElementById("SpanLuminosidade")

BtnOpenIluminacao.onclick = () => {
    if (ContainerLuminacao.style.display != 'flex') {
        ContainerLuminacao.style.display = 'flex'

    }else {
        ContainerLuminacao.style.display = 'none'
    }
}

InputIluminacao.addEventListener("click", (e) => {e.stopPropagation()})
InputIluminacao.oninput = () => {
    SpanLuminosidade.textContent = `${InputIluminacao.value}%`
}

BtnMusicOrVideo.onclick = () => {
    if (SpanTrocaMusicOrMovie.classList == 'fa-solid fa-video') {
        // Troca para Player de Música
        PlayerMusic.style.display = 'flex'
        PlayerVideo.style.display = 'none'

        SpanTrocaMusicOrMovie.classList = 'fa-solid fa-music'
        MovieOrSong.textContent = 'Musica'

        document.title = 'Player - Musica'

    } else {
        // Troca para Player de Vídeo
        PlayerMusic.style.display = 'none'
        PlayerVideo.style.display = 'flex'

        SpanTrocaMusicOrMovie.classList = 'fa-solid fa-video'
        MovieOrSong.textContent = 'Video'

        document.title = 'Player - Video'
    }
}

FecharArchive.onclick = () => ListPlayer.style.display = 'none'

BtnOpenArchive.onclick = () => ListPlayer.style.display = 'block'

// Abre a galeria de vídeos
BtnOpenVideosArchive.onclick = () => {
    PrintVideoArchive.style.display = 'flex'
    PrintMusicaArchive.style.display = 'none'

    BtnOpenVideosArchive.classList.add('ActiveSectionFilesActive')
    BtnOpenMusicasArchive.classList.remove('ActiveSectionFilesActive')
    CreateCardMovieArchive()
}

// Abre a galeria de músicas
BtnOpenMusicasArchive.onclick = () => {
    PrintVideoArchive.style.display = 'none'
    PrintMusicaArchive.style.display = 'flex'
    
    BtnOpenVideosArchive.classList.remove('ActiveSectionFilesActive')
    BtnOpenMusicasArchive.classList.add('ActiveSectionFilesActive')
    CreateCardMusicArchive()
}
