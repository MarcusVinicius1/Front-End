const LiHome = document.getElementById('LiHome')
const LiTime = document.getElementById('LiTime')
const LiCheckIn = document.getElementById('LiCheckIn')
const IndicatorSession = document.getElementById('IndicatorSession')

let LeftLi = 160
let LaguraLi = 53

IndicatorSession.style.left = LeftLi + 'px'
IndicatorSession.style.width = LaguraLi + 'px'

LiHome.onclick = () => {
    LeftLi = 40
    LaguraLi = 60

    IndicatorSession.style.left = LeftLi + 'px'
    IndicatorSession.style.width = LaguraLi + 'px'
    
    CronometroTime.style.display = 'none'
    PrintTreinoDeHoje.style.display = 'block'
    ContainerCheckIn.style.display = 'none'
}

LiTime.onclick = () => {
    LeftLi = 160
    LaguraLi = 53

    IndicatorSession.style.left = LeftLi + 'px'
    IndicatorSession.style.width = LaguraLi + 'px'
    
    CronometroTime.style.display = 'block'
    PrintTreinoDeHoje.style.display = 'none'
    ContainerCheckIn.style.display = 'none'
}

LiCheckIn.onclick = () => {
    LeftLi = 275
    LaguraLi = 80

    IndicatorSession.style.left = LeftLi + 'px'
    IndicatorSession.style.width = LaguraLi + 'px'

    CronometroTime.style.display = 'none'
    PrintTreinoDeHoje.style.display = 'none'
    ContainerCheckIn.style.display = 'flex'
}
