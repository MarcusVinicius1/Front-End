const BtnBackMusic = document.getElementById('BtnBackMusic')
const BtnPlayMusic = document.getElementById('BtnPlayMusic')
const BtnPauseMusic = document.getElementById('BtnPauseMusic')
const BtnNextMusic = document.getElementById('BtnNextMusic')
const InfoMusic = document.getElementById('InfoMusic')
const CapaMusic = document.getElementById('CapaMusic')
const SpanTime = document.getElementById('SpanTime')
const SpanDuration = document.getElementById('SpanDuration')
const ProgressBarra = document.getElementById('ProgressBarra')
const ContainerProgress = document.getElementById('ContainerProgress')
const GraficoOnMusic = document.getElementById('GraficoOnMusic')
const PrintMusicaArchive = document.getElementById('PrintMusicaArchive')

let IndexMusic = 0

const MusicasLista = [
    {
        Titulo: 'MÚSICA ELETRÔNICA 2024 🔥 AS MÚSICAS ELETRÔNICAS MAIS TOCADAS 🔥 Alok, Vintage Culture & David Guetta',
        src: 'Musicas/Um.mp3',
        Capa: 'Capa/Musicas/Um.jpg'
    },
    {
        Titulo: 'ＮＯＳＴＡＬＧＩＡ - PHONK MIX FOR NIGHT DRIVE - BEST LXST CXNTURY TYPE - 3 HOUR CAR MUSIC 2023',
        src: 'Musicas/Dois.mp3',
        Capa: 'Capa/Musicas/Dois.jpg'
    }
]

const AudioMusic = new Audio()

const FormatTime = n => n < 10 ? n = `0${n}` : n

function CreateCardMusicArchive() {
    PrintMusicaArchive.innerHTML = ''

    for (let i = 0; i < MusicasLista.length; i++) {
        const CardMusica = document.createElement('div')
        CardMusica.classList = 'CardMusica'

        const Img = document.createElement('img')
        Img.src = MusicasLista[i].Capa

        const H4Title = document.createElement("h4")
        H4Title.textContent = MusicasLista[i].Titulo

        CardMusica.onclick = () => {
            ListPlayer.style.display = 'none'

            PlayerMusic.style.display = 'flex'
            PlayerVideo.style.display = 'none'

            SpanTrocaMusicOrMovie.classList = 'fa-solid fa-music'
            MovieOrSong.textContent = 'Musica'

            document.title = 'Player - Musica'

            CapaMusic.src = MusicasLista[i].Capa
            AudioMusic.src = MusicasLista[i].src
            InfoMusic.textContent = MusicasLista[i].Titulo
            IndexMusic = i

            AudioMusic.play()
            GraficoOnMusic.style.display = 'flex'
            BtnPlayMusic.style.display = 'none'
            BtnPauseMusic.style.display = 'grid'
        }
    
        PrintMusicaArchive.appendChild(CardMusica)
        CardMusica.appendChild(Img)
        CardMusica.appendChild(H4Title)
    }
}

function updateTime() {
    // Progreso numerico
    const currentTime = AudioMusic.currentTime;
    const duration = AudioMusic.duration;

    const currentHours = Math.floor(currentTime / 3600);
    const currentMinutes = Math.floor((currentTime % 3600) / 60);
    const currentSeconds = Math.floor(currentTime % 60);

    // Duração
    const durationHours = isNaN(duration) ? 0 : Math.floor(duration / 3600);
    const durationMinutes = isNaN(duration) ? 0 : Math.floor((duration % 3600) / 60);
    const durationSeconds = isNaN(duration) ? 0 : Math.floor(duration % 60);

    // Progreso barra
    const progressWidth = isNaN(duration) || duration === 0 ? 0 : (currentTime / duration) * 100;

    // Exibindo valores
    SpanTime.textContent = `${FormatTime(currentHours)} : ${FormatTime(currentMinutes)} : ${FormatTime(currentSeconds)}`
    SpanDuration.textContent = `${FormatTime(durationHours)} : ${FormatTime(durationMinutes)} : ${FormatTime(durationSeconds)}`
    ProgressBarra.style.width = `${progressWidth}%`
}

function loop() {
    if (!MusicasLista[IndexMusic].src.endsWith('.mp3')) {
        alert("Não é uma musica")
        return
    }

    CapaMusic.src = MusicasLista[IndexMusic].Capa
    AudioMusic.src = MusicasLista[IndexMusic].src
    InfoMusic.textContent = MusicasLista[IndexMusic].Titulo

    updateTime()
    AudioMusic.addEventListener('timeupdate', updateTime)
}

ContainerProgress.onclick = (e) => {
    const newTime = (e.offsetX / ProgressBarra.offsetWidth) * AudioMusic.duration

    AudioMusic.currentTime = newTime
}

// Função para alterar a música de maneira eficiente
function changeMusic(index) {
    CapaMusic.src = MusicasLista[index].Capa
    AudioMusic.src = MusicasLista[index].src
    InfoMusic.textContent = MusicasLista[index].Titulo
    AudioMusic.play()
    GraficoOnMusic.style.display = 'flex'
    BtnPlayMusic.style.display = 'none'
    BtnPauseMusic.style.display = 'grid'
}

// Alterando música ao clicar no botão "Voltar"
BtnBackMusic.onclick = () => {
    IndexMusic = (IndexMusic - 1 + MusicasLista.length) % MusicasLista.length;
    changeMusic(IndexMusic);
}

// Alterando música ao clicar no botão "Próximo"
BtnNextMusic.onclick = () => {
    IndexMusic = (IndexMusic + 1) % MusicasLista.length;
    changeMusic(IndexMusic);
}

// Iniciando a música e mostrando o gráfico de progressão
BtnPlayMusic.onclick = () => {
    AudioMusic.play()
    GraficoOnMusic.style.display = 'flex'
    BtnPlayMusic.style.display = 'none'
    BtnPauseMusic.style.display = 'grid'
}

// Pausando a música e ocultando o gráfico de progressão
BtnPauseMusic.onclick = () => {
    AudioMusic.pause()
    GraficoOnMusic.style.display = 'none'
    BtnPlayMusic.style.display = 'grid'
    BtnPauseMusic.style.display = 'none'
}

loop()
